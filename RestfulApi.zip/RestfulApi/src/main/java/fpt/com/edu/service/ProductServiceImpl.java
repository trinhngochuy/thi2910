package fpt.com.edu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fpt.com.edu.entity.ProductEntity;
import fpt.com.edu.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepository productRepository;
	
	
	@Override
	public void saveProduct(ProductEntity u) {
		productRepository.save(u);
		
	}

	@Override
	public void sellProduct(ProductEntity u) {
		int quantity = u.getQuantity() - 1;
		u.setQuantity(quantity);
		productRepository.save(u);
	}

	@Override
	public void deleteUser(Integer id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ProductEntity findById(Integer id) {
		ProductEntity pro = productRepository.findById(id).get();
		return pro;
	}

	@Override
	public List<ProductEntity> findAll() {
		return productRepository.findAll();
	}

	@Override
	public List<ProductEntity> findAllByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}



}
