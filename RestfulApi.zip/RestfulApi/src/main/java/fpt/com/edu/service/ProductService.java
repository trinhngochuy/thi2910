package fpt.com.edu.service;

import java.util.List;

import fpt.com.edu.entity.*;

public interface ProductService {
	public void saveProduct(ProductEntity u);
	public void sellProduct(ProductEntity u);
    public void deleteUser(Integer id);
    public ProductEntity findById(Integer id);
    public List<ProductEntity> findAll();
    public List<ProductEntity> findAllByName(String name);
}
