package fpt.com.edu.controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import fpt.com.edu.entity.UserEntity;
import fpt.com.edu.service.*;

@RestController
public class UserController {
	
@Autowired
UserService userService;

@RequestMapping(value ="user",method = RequestMethod.GET)
public Object findAllUser(){
	List<UserEntity> listu = userService.findAll();
	return listu;
	}

//
////user/x
//@RequestMapping(value = "user/{id}", method = RequestMethod.GET)
//public ResponseEntity<UserEntity> findUserById(@PathVariable("id") Integer id) {
//	UserEntity u = userService.findById(id);
//    return new ResponseEntity<UserEntity>(u, HttpStatus.OK);
//}
//
//
//@RequestMapping(value = "userbyname", method = RequestMethod.GET)
//public ResponseEntity<List<UserEntity>> findAllUser(@PathParam("name") String name) {
//    List<UserEntity> lsUser = userService.findAllByName(name);
//    if(lsUser.size() == 0) {
//        return new ResponseEntity(HttpStatus.NO_CONTENT);
//    }
//    return new ResponseEntity<List<UserEntity>>(lsUser, HttpStatus.OK);
//}
//
//@RequestMapping(value = "user", method = RequestMethod.POST)
//public ResponseEntity<UserEntity> saveNewUser(@RequestBody UserEntity u) {
//    userService.saveUser(u);
//    return new ResponseEntity<UserEntity>(u, HttpStatus.OK);
//}
//
////http://localhost:8080/updateUser?id=1
//@RequestMapping(value = "user", method = RequestMethod.PUT)
//public ResponseEntity<UserEntity> updateUser(
//        @PathParam("id") Integer id,
//        @RequestBody UserEntity u) {
//	UserEntity oldUser = userService.findById(id);
//    oldUser.setEmail(u.getEmail());
//    oldUser.setName(u.getName());
//    oldUser.setPhone(u.getPhone());
//    userService.saveUser(oldUser);
//    return new ResponseEntity<UserEntity>(oldUser, HttpStatus.OK);
//}
//
//@RequestMapping(value = "deleteuser/{id}", method = RequestMethod.DELETE)
//public ResponseEntity<UserEntity> deleteUser(@PathVariable(value = "id") Integer id) {
//    userService.deleteUser(id);
//    return ResponseEntity.ok().build();
//}
}
