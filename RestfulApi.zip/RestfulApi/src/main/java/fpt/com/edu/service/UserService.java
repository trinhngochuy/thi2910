package fpt.com.edu.service;

import java.util.List;

import fpt.com.edu.entity.UserEntity;

public interface UserService {
	public void saveUser(UserEntity u);
    public void deleteUser(Integer id);
    public UserEntity findById(Integer id);
    public List<UserEntity> findAll();
    public List<UserEntity> findAllByName(String name);
}
