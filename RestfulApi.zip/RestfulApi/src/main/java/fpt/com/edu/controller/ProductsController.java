package fpt.com.edu.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import fpt.com.edu.entity.ProductEntity;
import fpt.com.edu.entity.UserEntity;
import fpt.com.edu.service.*;

@RestController
public class ProductsController {
	@Autowired
	ProductServiceImpl productservice;
	
	@RequestMapping(value ="products",method = RequestMethod.GET)
	public Object findAllUser(){
		List<ProductEntity> listu = productservice.findAll();
		return listu;
		}
	@RequestMapping(value = "user/{id}", method = RequestMethod.GET)
	public ResponseEntity<UserEntity> findUserById(@PathVariable("id") Integer id) {
		ProductEntity u = productservice.findById(id);
		productservice.sellProduct(u);
	    return new ResponseEntity<>(HttpStatus.OK);
	}
	@RequestMapping(value = "user", method = RequestMethod.POST)
	public ResponseEntity<ProductEntity> saveNewProduct(@RequestBody ProductEntity u) {
		productservice.saveProduct(u);
	    return new ResponseEntity<ProductEntity>(u, HttpStatus.OK);
	}
}
