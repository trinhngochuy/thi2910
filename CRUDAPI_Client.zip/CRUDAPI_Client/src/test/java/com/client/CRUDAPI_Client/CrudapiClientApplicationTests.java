package com.client.CRUDAPI_Client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudapiClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
