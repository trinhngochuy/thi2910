package com.client.CRUDAPI_Client;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudapiClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudapiClientApplication.class, args);
	}

}
