package com.client.CRUDAPI_Client.controller;

import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.logging.LoggingFeature;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.client.CRUDAPI_Client.model.Product;
import com.client.CRUDAPI_Client.model.User;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller 
public class ProductController {
	 private final String REST_API_LIST = "http://localhost:8805/products";
	 private final String REST_API_CREATE = "http://localhost:8805/user";
	 private final String REST_API_SELL = "http://localhost:8805/user/";
	    private static Client createJerseyRestClient() {
	    	   
	        ClientConfig clientConfig = new ClientConfig();
	        // Config logging for client side
	        clientConfig.register( //
	                new LoggingFeature( //
	                        Logger.getLogger(LoggingFeature.DEFAULT_LOGGER_NAME), //
	                        Level.INFO, //
	                        LoggingFeature.Verbosity.PAYLOAD_ANY, //
	                        10000));

	        return ClientBuilder.newClient(clientConfig);
	    }
	    @GetMapping(value = "/products")
	    public String index(Model model) {
	        Client client = createJerseyRestClient();
	        WebTarget target = client.target(REST_API_LIST);
	        List<Product> ls =  target.request(MediaType.APPLICATION_JSON_TYPE).get(List.class);
//	        System.out.println("Lis Size: " + ls.size());
	        model.addAttribute("lsUser", ls);
	   
	        return "products";
	    }
	    @GetMapping(value = "/create")
	    public String create(Model model) {   
	        return "create";
	    }
	    @GetMapping(value = "sell")
	    public String sell(@RequestParam(name="id", required = true) int id,Model model) {   
	    	String url = REST_API_SELL + id;
	    	   Client client = createJerseyRestClient();
		       WebTarget target = client.target(url);
	        return  "redirect:/products";
	    }
	    @PostMapping(value = "/createProduct")
	    public String saveUser(@RequestParam String name,
	                           @RequestParam int quantity,
	                           @RequestParam double price) {
	        Product u = new Product();
	        u.setName(name);
	        u.setPrice(price);
	        u.setQuantity(quantity);
	        
	        String jsonUser = convertToJson(u);

	        Client client = createJerseyRestClient();
	        WebTarget target = client.target(REST_API_CREATE);
	        Response response = target.request(MediaType.APPLICATION_JSON_TYPE)
	                .post(Entity.entity(jsonUser, MediaType.APPLICATION_JSON));
	        return "redirect:/products";
	    }
	    private static String convertToJson(Product product) {
	        ObjectMapper mapper = new ObjectMapper();
	        try {
	            return mapper.writeValueAsString(product);
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        return null;
	    }
}
