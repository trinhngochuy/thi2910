package com.client.CRUDAPI_Client.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.client.CRUDAPI_Client.model.User;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.logging.LoggingFeature;

import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
@Controller 
public class UserController {
	 private final String REST_API_LIST = "http://localhost:8805/user";
	    private final String REST_API_CREATE = "http://localhost:8080/user";
	    private final String REST_API_DELETE = "http://localhost:8080/deleteuser/";
	    private final String REST_API_UPDATE = "http://localhost:8080/user";
	
    private static Client createJerseyRestClient() {
   
        ClientConfig clientConfig = new ClientConfig();
        // Config logging for client side
        clientConfig.register( //
                new LoggingFeature( //
                        Logger.getLogger(LoggingFeature.DEFAULT_LOGGER_NAME), //
                        Level.INFO, //
                        LoggingFeature.Verbosity.PAYLOAD_ANY, //
                        10000));

        return ClientBuilder.newClient(clientConfig);
    }
	
    @GetMapping(value = "/")
    public String index(Model model) {
        Client client = createJerseyRestClient();
        WebTarget target = client.target(REST_API_LIST);
        List<User> ls =  target.request(MediaType.APPLICATION_JSON_TYPE).get(List.class);
        System.out.println("Lis Size: " + ls.size());
        model.addAttribute("lsUser", ls);
        return "index";
    }

    @GetMapping(value = "createnewuser")
    public String createNewUser() {
        return "createnewuser";
    }
    @PostMapping("saveuser")
    public String saveUser(@RequestParam String name,
                           @RequestParam String email,
                           @RequestParam String phone) {
        User u = new User();
        u.setName(name);
        u.setEmail(email)
;
        u.setPhone(phone)
;

        String jsonUser = convertToJson(u);

        Client client = createJerseyRestClient();
        WebTarget target = client.target(REST_API_CREATE);
        Response response = target.request(MediaType.APPLICATION_JSON_TYPE)
                .post(Entity.entity(jsonUser, MediaType.APPLICATION_JSON));
        return "redirect:/listuser";
    }
    private static String convertToJson(User user) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.writeValueAsString(user);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
